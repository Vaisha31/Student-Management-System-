<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BankAccountController;
use App\Http\Controllers\DashBoardController;
use App\Http\Controllers\ExpenseTypeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\PaymentController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();


});

Route::post('/save-bank-account',[BankAccountController::class,'store']);
Route::post('/save-expense-type',[ExpenseTypeController::class,'store']);
Route::get('/expenseTypes',[ExpenseTypeController::class,'index']);
Route::get('/banks',[BankAccountController::class,'index']);

// Route::get('/get-csrf-token', function() {
//     return response()->json(['csrf_token' => csrf_token()]);
// });


Route::get('/dashboardDetails',[DashBoardController::class,'index']);
Route::post('/Oauth/login',[LoginController::class,'login']);





Route::prefix('payment')->group(function () {

    Route::get('/getStudentDetails/{id}',[PaymentController::class,'search']);
    Route::post('/payPayment',[PaymentController::class,'payPayment']);

});



