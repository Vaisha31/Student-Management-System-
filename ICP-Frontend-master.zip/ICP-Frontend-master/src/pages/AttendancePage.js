import React from 'react';

const AttendancePage = () => (
  <div>
    <h2>Attendance</h2>
    <p>Manage attendance records here.</p>
  </div>
);

export default AttendancePage;
