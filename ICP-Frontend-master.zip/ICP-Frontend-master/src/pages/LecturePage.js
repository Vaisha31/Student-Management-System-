import React from 'react';

const LecturePage = () => (
  <div>
    <h2>Lecture</h2>
    <p>Schedule and manage lectures here.</p>
  </div>
);

export default LecturePage;
