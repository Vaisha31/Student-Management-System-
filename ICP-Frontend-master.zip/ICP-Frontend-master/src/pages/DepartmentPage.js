import React from 'react';

const DepartmentPage = () => (
  <div>
    <h2>Department</h2>
    <p>Manage departments here.</p>
  </div>
);

export default DepartmentPage;
