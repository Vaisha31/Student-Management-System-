import React from 'react';

const BatchPage = () => (
  <div>
    <h2>Batch</h2>
    <p>Manage batches here.</p>
  </div>
);

export default BatchPage;
