import React from 'react';

const StudentDetailsPage = () => (
  <div>
    <h2>Student Details</h2>
    <p>View and edit student details here.</p>
  </div>
);

export default StudentDetailsPage;
