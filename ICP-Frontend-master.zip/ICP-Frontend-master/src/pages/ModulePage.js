import React from 'react';

const ModulePage = () => (
  <div>
    <h2>Module</h2>
    <p>Manage modules here.</p>
  </div>
);

export default ModulePage;
