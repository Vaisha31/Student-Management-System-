import React from 'react';

const AssignToModulePage = () => (
  <div>
    <h2>Assign to Module</h2>
    <p>Assign resources to modules here.</p>
  </div>
);

export default AssignToModulePage;
