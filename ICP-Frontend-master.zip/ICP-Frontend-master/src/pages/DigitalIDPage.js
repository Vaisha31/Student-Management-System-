import React from 'react';

const DigitalIDPage = () => (
  <div>
    <h2>Digital ID</h2>
    <p>Manage digital IDs here.</p>
  </div>
);

export default DigitalIDPage;
