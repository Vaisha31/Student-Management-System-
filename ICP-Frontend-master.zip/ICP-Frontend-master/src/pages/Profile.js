import React from 'react';

const Profile = () => <div>Profile Page Content</div>;

export default Profile;