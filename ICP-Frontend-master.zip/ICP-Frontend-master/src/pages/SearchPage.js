import React from 'react';

const SearchPage = () => {
  return <div>Search Page</div>;
};

export default SearchPage;