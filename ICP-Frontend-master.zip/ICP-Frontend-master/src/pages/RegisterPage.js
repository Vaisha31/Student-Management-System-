import React from 'react';

const RegisterPage = () => (
  <div>
    <h2>Register</h2>
    <p>Create a new account here.</p>
  </div>
);

export default RegisterPage;
