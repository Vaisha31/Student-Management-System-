import React from 'react';

const TimeTablePage = () => (
  <div>
    <h2>Time Table</h2>
    <p>Manage time tables here.</p>
  </div>
);

export default TimeTablePage;
