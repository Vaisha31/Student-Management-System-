import React from 'react';

const Settings = () => <div>Settings Page Content</div>;

export default Settings;
