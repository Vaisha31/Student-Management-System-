import React, { useState, useEffect } from "react";
import axios from "axios";
import { Box, Button, Select, MenuItem, TextField, Typography, Modal } from "@mui/material";

const AddBankModal = ({ open, handleClose }) => {
  const [bank, setBank] = useState("");
  const [accountNo, setAccountNo] = useState("");
  const [openingBalance, setOpeningBalance] = useState("");


  const handleSubmit = async () => {

    if (!bank || !accountNo || !openingBalance) {
      alert("Please fill in all fields");
      return;
    }

    const formData = {
      bank,
      account_no: accountNo,
      opening_balance: openingBalance,
    };

    try {

      const response = await axios.post(
        "http://localhost:8000/api/save-bank-account", 
        formData,{
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response.status === 200) {
        alert("Bank account saved successfully!");
        handleClose();
        
      }
    } catch (error) {
      console.error("Error saving bank account:", error);
      alert("Failed to save the bank account. Please try again.");
    }
  };

  return (
    <Modal open={open} onClose={handleClose}>
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: 400,
          bgcolor: "background.paper",
          boxShadow: 24,
          p: 4,
          borderRadius: 2,
        }}
      >
        {/* Header */}
        <Typography
          variant="h6"
          align="center"
          sx={{
            bgcolor: "lightgreen",
            p: 1,
            borderRadius: 1,
            marginBottom: 2,
            fontWeight: "bold",
          }}
        >
          Add New Bank Account
        </Typography>

        {/* Form Fields */}
        <Box component="form" noValidate autoComplete="off">
          <Box sx={{ display: "flex", gap: 2, marginBottom: 2 }}>
            <Select
              fullWidth
              value={bank}
              onChange={(e) => setBank(e.target.value)}
              displayEmpty
            >
              <MenuItem value="" disabled>
                Bank
              </MenuItem>
              <MenuItem value="Bank of Ceylon">Bank of Ceylon</MenuItem>
              <MenuItem value="Commercial Bank">Commercial Bank</MenuItem>
              <MenuItem value="HSBC">HSBC</MenuItem>
            </Select>
            <TextField
              fullWidth
              label="Account No"
              variant="outlined"
              value={accountNo}
              onChange={(e) => setAccountNo(e.target.value)}
            />
          </Box>

          <TextField
            fullWidth
            label="Opening Balance"
            variant="outlined"
            value={openingBalance}
            onChange={(e) => setOpeningBalance(e.target.value)}
            sx={{ marginBottom: 2 }}
          />

          {/* Submit Button */}
          <Button variant="contained" color="primary" fullWidth onClick={handleSubmit}>
            Submit
          </Button>
        </Box>
      </Box>
    </Modal>
  );
};

export default AddBankModal;
