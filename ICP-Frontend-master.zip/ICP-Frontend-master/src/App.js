import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import { Box, IconButton, useTheme, useMediaQuery } from "@mui/material";
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import MenuIcon from "@mui/icons-material/Menu";
import DashboardPage from "./pages/DashboardPage";
import DepartmentPage from "./pages/DepartmentPage";
import ModulePage from "./pages/ModulePage";
import BatchPage from "./pages/BatchPage";
import StudentDetailsPage from "./pages/StudentDetailsPage";
import DigitalIDPage from "./pages/DigitalIDPage";
import LecturePage from "./pages/LecturePage";
import AssignToModulePage from "./pages/AssignToModulePage";
import PaymentPage from "./pages/PaymentPage";
import TimeTablePage from "./pages/TimeTablePage";
import AttendancePage from "./pages/AttendancePage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import SearchPage from './pages/SearchPage';
import ExpensesPage from './pages/ExpensesPage';
import ExpenseTypesPage from './pages/ExpenseTypesPage';
import AddAccountPage from './pages/AddAccountPage';
import AccountsPage from './pages/AccountsPage';
import AuthenticatedRoute from '../src/components/AuthenticatedRoute'
import './App.css';

const App = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  return (
    <Router>
      <Routes>
        {/* Wrap only the routes that need sidebar and header */}
        <Route
          path="/*"
          element={
            <Layout
              mobileOpen={mobileOpen}
              handleDrawerToggle={handleDrawerToggle}
              isMobile={isMobile}
            />
          }
        />
        <Route path="/" element={<LoginPage />} />
      </Routes>
    </Router>
  );
};

const Layout = ({ mobileOpen, handleDrawerToggle, isMobile }) => {
  const location = useLocation();

  const showSidebarAndHeader = !["/login"].includes(location.pathname);

  const isAccountsPage = location.pathname === '/payment/accounts';

  return (
    <Box>
      {/* Conditionally render Header and Sidebar */}
      {showSidebarAndHeader && <Header />}
      <Box sx={{ display: "flex", minHeight: "100vh" }}>
        {showSidebarAndHeader && isMobile && (
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{
              position: "fixed",
              left: 16,
              top: 16,
              zIndex: 1200,
            }}
          >
            <MenuIcon />
          </IconButton>
        )}

        {showSidebarAndHeader && (
          <Sidebar mobileOpen={mobileOpen} onDrawerToggle={handleDrawerToggle} />
        )}

        <Box
          component="main"
          sx={{
            flexGrow: 1,
            width: { sm: `calc(100% - ${240}px)` },
            p: 3,
            backgroundColor: isAccountsPage ? '#F3F4F6' : 'inherit',
          }}
        >
          <Box sx={{ mt: 8 }}>
            <Routes>
              
                <Route path="/department" element={<AuthenticatedRoute><DepartmentPage /> </AuthenticatedRoute>} />
                <Route path="/dashboard" element={<AuthenticatedRoute><DashboardPage /></AuthenticatedRoute>} />
                <Route path="/module" element={<AuthenticatedRoute><ModulePage /> </AuthenticatedRoute>} />
                <Route path="/batch" element={<AuthenticatedRoute><BatchPage /> </AuthenticatedRoute>} />
                <Route path="/student-details" element={<AuthenticatedRoute><StudentDetailsPage /> </AuthenticatedRoute>} />
                <Route path="/digital-id" element={<AuthenticatedRoute><DigitalIDPage /> </AuthenticatedRoute>} />
                <Route path="/lecture" element={<AuthenticatedRoute><LecturePage /> </AuthenticatedRoute>} />
                <Route path="/assign-to-module" element={<AuthenticatedRoute><AssignToModulePage /> </AuthenticatedRoute>} />
                <Route path="/payment" element={<AuthenticatedRoute><PaymentPage /> </AuthenticatedRoute>} />
                <Route path="/payment/search" element={<AuthenticatedRoute><SearchPage /> </AuthenticatedRoute>} />
                <Route path="/payment/expenses" element={<AuthenticatedRoute><ExpensesPage /> </AuthenticatedRoute>} />
                <Route path="/payment/expense-types" element={<AuthenticatedRoute><ExpenseTypesPage /> </AuthenticatedRoute>} />
                <Route path="/payment/add-account" element={<AuthenticatedRoute><AddAccountPage /> </AuthenticatedRoute>} />
                <Route path="/payment/accounts" element={<AuthenticatedRoute><AccountsPage /> </AuthenticatedRoute>} />
                <Route path="/time-table" element={<AuthenticatedRoute><TimeTablePage /> </AuthenticatedRoute>} />
                <Route path="/attendance" element={<AuthenticatedRoute><AttendancePage /> </AuthenticatedRoute>} />
                <Route path="/register" element={<AuthenticatedRoute><RegisterPage /> </AuthenticatedRoute>} />
             
            </Routes>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default App;
